'use strict'
const uuid = require('node-uuid');
const todoCollections = require('./todoItems');
const todo = todoCollections.todoItems;


let exportedMethods = {

	createTask(title, description){

		if(!title){
			return Promise.reject("you must provide a name for your Task");
		}

		if(!description){
			return Promise.reject("You must provide description for your task");
		}

		var uniqueID = uuid.v1();
		let bytes = uuid.parse(uniqueID);
		let string = uuid.unparse(bytes);

		return todo().then((todoItemsCollection) => {

			let newTask = {
				_id: string,
				title: title,
				description: description,
				completed: false,
				completedAt: null
			};

			return todoItemsCollection	
				.insertOne(newTask)
				.then((newInsertInformation) => {
					return newInsertInformation.insertedId;
				})
				.then((newId) => {	
					return this.getTask(newId);
				});
		}).catch((err) => {
			console.log(err);
		})

	},


	getTask(id){
		if(!id){
			return Promise.reject("You must provide an ID to search for!!");
		}

		let bytes = uuid.parse(id);
		let string = uuid.unparse(bytes);

		return todo().then((todoItemsCollection) => {
			return todoItemsCollection.findOne({_id : string});
		}).catch((err) => {
			console.log(err);
		});	
	},


	removeTask(id){

		if(!id){
			return Promise.reject("You must provide an Id");
		}

		let bytes = uuid.parse(id);
		let string = uuid.unparse(bytes);

		return todo().then((todoItemsCollection) => {
			return todoItemsCollection
				.removeOne({_id:string})
				.then((deleteInfo) => {
					if(deleteInfo.deletedCount == 0){
						throw(`Could not Delete task with id of ${string}`);
					}else{
						throw (`${string} Deleted`);
					}
				});
		}).catch((err) => {
			console.log(err);
		});
	},

	completeTask(taskId){
		if(!taskId){
			return Promise.reject("You must provide an id to search");
		}

		let bytes = uuid.parse(taskId);
		let string = uuid.unparse(bytes);

		return todo().then((todoItemsCollection) => {
			let finishedTask = {
				$set : {
					title: "Play Pokemon with Twitch TV",
					description : "Should we revive Helix?",
					completed: true,
					completedAt: new Date()
				} 	
			};	

		return todoItemsCollection.updateOne({
			_id:string
		}, finishedTask).then(() => {
			return this.getTask(string);
			console.log("\n");
			});

		}).catch((err) => {
			console.log(err);
		});

	},

	getAllTasks(){
		return todo().then((todoItemsCollection) => {
			console.log("\n");
			return todoItemsCollection.find().toArray((err,docs) => {
				docs.forEach((docs) => {
					console.log("\n");
					console.log(docs);
				});
			});	
		}).catch((err) => {
			console.log(err);
		});

	}
}

module.exports = exportedMethods;	