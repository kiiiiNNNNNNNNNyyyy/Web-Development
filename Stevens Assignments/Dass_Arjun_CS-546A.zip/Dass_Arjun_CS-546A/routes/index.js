'use strict'
const apiRoutes = require("./api");
const todoData = require('../data');

const constructorMethod = (app) => {
    app.use("/api", apiRoutes);

    app.get("/", function (request, response) {
        response.render("notes", { pageTitle: "So Much ToDo!", todoItems: todoData.getAll() });
    });

    app.get("/new", function (request, response) {
        response.render("test", { pageTitle: "Test!"});
    });

    app.get("/notes", function(req, res){
        res.render("notes", {pageTitle: "All Tasks!"});
    });
    
    app.use("*", (req, res) => {
        res.sendStatus(404);
    });
};

module.exports = constructorMethod;