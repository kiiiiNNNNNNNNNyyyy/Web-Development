'use strict'
const todoItems = require('./todo.js');
const connection = require('./dbConnection');

console.log("Please Read 'README BEFORE EXECUTION' file for  proper and clear execution");
let createdTask = todoItems.createTask("Ponder Dinosaurs", "Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?");
let taskAdded = createdTask.then((newTask) => {
	console.log(newTask);
}).catch((err) => {
	console.log(err);
});

let createdTask2 = todoItems.createTask("Play Pokemon with Twitch TV", "Should we revive Helix?")
	.catch((err) => {
		console.log(err);
});


let allTasks = taskAdded.then(() => {
    return todoItems.getAllTasks();
}).catch((err) => {
	console.log(err);
});

/*

//                     REMOVE TASK                                  //

let removeTask = todoItems.removeTask('PASTE ID TO BE REMOVED HERE');
let tryToGetTask = removeTask.then(() => {
	return todoItems.getTask('PASTE ID TO BE REMOVED HERE');
}).catch((err) => {
	console.log(err);
});
	
let allTasks2 = tryToGetTask.then(() => {
    return todoItems.getAllTasks();
}).catch((err) => {
	console.log(err);
});


//                     COMPLETE TASK                             //
/*
let taskPromise = todoItems.getTask('PASTE ID TO BE UPDATED HERE');
let finishedTask = taskPromise.then((task) => {
	return todoItems.completeTask(task._id);
}).then((completedTask) => {
	console.log(completedTask);
}).catch((err) => {
	console.log(err);
});

 
let allTasks3	 = finishedTask.then(() => {
    return todoItems.getAllTasks();
}).catch((err) => {
	console.log(err);
});
*/