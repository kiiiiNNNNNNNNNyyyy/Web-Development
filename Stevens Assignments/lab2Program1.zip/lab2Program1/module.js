'use strict'

const fs = require('fs');
const prompt = require('prompt');

let customModule = exports = module.exports;

customModule.getFileAsString = (path) => {
	return new Promise((fulfill, reject) => {
		if(!path) throw "No Filne name was Provided";

		fs.readFile(path, "utf-8", (error, data) => {

			if(error){
				reject(error);
				return;
			}

			try{
				console.log("\n");
				console.log("/***************************** Program 1 **********************/");
				console.log("                          Get File as String                     ");
				console.log( "\n" + data.toString() + "\n");

			}catch(error){
				reject(error);
			}
		});
	});
};

/********************* End of Program One *****************************/

customModule.getFileAsJSON = (path) => {

	return new Promise((fulfill, reject) => {
		if(!path) throw "No Filename  has been Provided";

		fs.readFile(path, "utf-8", (error, data) => {
			
			if(error){
				reject(error);
				return;
			}

			try{
				console.log("\n");
				// unnecessay log to distingish between programs
				console.log("/***************************** Program 2 **********************/");
				console.log("                          Get JSON as String                     ");
				console.log("\n");
				console.log(JSON.parse(data));
				// unnecessay log to distingish between programs
				console.log("\n");
				console.log("/***************************** Program 3 **********************/\n");
				console.log("Enter string to be written on your file");
			}catch(error){
				reject(error);
			}
		});
	});
};


/********************************** End of Prgram two ******************/

customModule.saveStringToFile = (path, text, callback) => {
	return new Promise((fulfill, reject)  => {
		fs.writeFile(path, text, callback);
	});
	if(error){
		reject(error);
		return;
	}	
	try{
		console.log("written");
	}catch(error){
		reject(error);
	}
};

/************************************* End of Program three ****************/

customModule.saveJSONToFile = (fileName, callback) => {

	return new Promise((fulfill, reject) => {
		if(!fileName) throw "No Filename is Provided";

		fs.readFile("Data.json", "utf-8", (error, data) => {
			if(error){
				reject(error);
				return;
			}

			try{
				let jsonData = JSON.stringify(data,null, 4);
				fs.writeFile("yourJsonText.txt", jsonData,(error, data) => {
					if(error){
						console.log(error);
						reject(error);
						return;
					}

					fulfill(data);
				});
				
			}catch(error){
				reject(error);
			}
		});	
	});
};