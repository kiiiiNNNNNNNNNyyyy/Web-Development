module.exports = {
	database: 'mongodb://root:loginsystem@ds113628.mlab.com:13628/loginsystem',
	port: 3000,
	secretKey: "arjun"
}