'use strict'
const educationRoutes = require("./education");
const hobbyRoutes = require("./hobby");
const hobbyDescriptionRoutes = require("./hobbyDescription")
const classesRoutes = require("./classes");
const classesDescriptionRoutes = require('./classesDescription');

const constructorMethod = (app) => {
    app.use("/education", educationRoutes);
    app.use("/classes", classesRoutes);
    app.use("/hobbies", hobbyRoutes);

    app.use("*", (req, res) => {
        res.sendStatus(404);
    });
};

module.exports = constructorMethod;