'use strict'
const express = require('express');
const router = express.Router();
const xss = require('xss');
var fs = require('fs');

router.post("/todo", function (request, response) {
    console.log(request.body);
    response.json({ success: true, message: xss(request.body.description) });
});

router.post("/todo.html", function (request, response) {
    console.log(request.body);
    response.send("<div>" + xss(request.body.description) + "</div>");
});

router.post("/new", function(request, response){
	console.log(request.body);
	var test  = {
		title: request.body.title,
		dueDate: request.body.dueDate,
		summary: request.body.summary,
		body: request.body.body
	}
	fs.appendFile('file.json', JSON.stringify(test), function(err, done){
		if(err) console.log('Something Went Wrong!!');
		console.log("File Written!!");
	});
	response.json({success: true, message:  xss(request.body.body)});
});

module.exports = router;