'use strict'
const mongoCollections = require("../config/mongoCollections");
const education = mongoCollections.education;
const highSchool = mongoCollections.highSchool;
const underGrad = mongoCollections.underGrad;
const uuid = require('node-uuid');


let exportedMethods = {
    getAllEducation() {
        return education().then((educationCollection) => {
            return educationCollection.find({}).toArray();
        });
    },

    getHighSchool(){
        return highSchool().then((educationCollection)=> {
            return educationCollection.find({}).toArray();
        });
    },

    getCollege(){
        return underGrad().then((educationCollection) => {
            return educationCollection.find({}).toArray();
        });
    },

    addEducation(highSchool, college){
        return education().then((educationCollection) => {
            let newEducation = {
                highSchool: highSchool,
                college: college,
                _id: uuid.v4()
            };

            return educationCollection.insertOne(newEducation).then((newInssertedEducation) => {
                return newInssertedEducation.insertedId;
            }).then((newId) => {
                return newId;
            });
        });
    },

    addHighSchool(highSchoolName){
        return highSchool().then((educationCollection) => {
            let newHighSchool = {
                highSchoolName: highSchoolName,
                _id: uuid.v4()
            };

            return educationCollection.insertOne(newHighSchool).then((newInssertedHighSchool) => {
                return newInssertedHighSchool.insertedId;
            }).then((newId) => {
                return newId;
            });
        });
    },

    addUnderGrad(undergrad, degree){
        return underGrad().then((educationCollection) => {
            let newUndergrad = {
                undergrad: undergrad,
                degree: degree,
                _id: uuid.v4()
            };

            return educationCollection.insertOne(newUndergrad).then((newInssertedUndergrad) => {
                return newInssertedUndergrad.insertedId;
            }).then((newId) => {
                return newId;
            });
        });
    }
}

module.exports = exportedMethods;