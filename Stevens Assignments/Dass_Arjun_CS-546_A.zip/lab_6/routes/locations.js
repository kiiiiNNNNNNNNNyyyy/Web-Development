'use strict'

const express = require('express');
const router = express.Router();
const data = require("../data");
const locationData = data.locations;
const eventsData = data.events;

// Location Index Page
router.get("/", (req, res) => {
    locationData.getAllLocations().then((locations) => {
    	res.render("misc/location", { locations: locations});
    }).catch((err => {  
    	console.log(err);
    }));
});


// Single Location Page
router.get("/:id", (req, res) => {
    // Find a location by the provided id, 
    // then display its information
    // As well as listing all events that will be at this location
    // Each of these events need to link to the event page and show the event name
    // If a location is not found, display the 404 error page
    locationData.getLocation(req.params.id).then((location) => {
        let locId = location.id;
        let locationName = location.name;
        let locate = location.location;
        eventsData.getEventByLocation(locId).then((allData) => {
            var data = {};
            data.eventId = allData.id;
            data.eventTitle = allData.title;
            data.locationId = locId;
            data.locationName= locationName;
            data.eventStartTime = allData.startTime;
            data.location = locate;
            data.eventAttendees = allData.attendees;
            console.log(data)
            var transfer = data;
            res.render("misc/location", {location: transfer}); 
        });
    });
});


module.exports = router;