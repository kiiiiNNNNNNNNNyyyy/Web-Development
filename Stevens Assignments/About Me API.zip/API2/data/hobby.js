'use strict'
const mongoCollections = require("../config/mongoCollections");
const hobby = mongoCollections.hobby;
const hobbyDescription = mongoCollections.hobbyDescription;
const uuid = require('node-uuid');

let exportedMethods = {
    
    getHobbyById(id) {
        return hobby().then((hobbyCollection) => {
            return hobbyCollection.findOne({_id: id}).then((hobby) => {
                if (!hobby) throw "Hobby not found";
                return hobby;
            });
        });
    },

    getAllHobby() {
        return hobby().then((hobbyCollection) => {
            return hobbyCollection.find({}).toArray();
        });
    },
    
    addHobby(hobbyName) {
        return hobby().then((hobbyCollection) => {
            let newHobby = {
                hobbyName: hobbyName,
                _id: uuid.v4()
            };

            return hobbyCollection.insertOne(newHobby).then((newInsertedHobby) => {
                return newInsertedHobby.insertedId;
            }).then((newId) => {
                return this.getHobbyById(newId);
            });
        });
    },

}

module.exports = exportedMethods;