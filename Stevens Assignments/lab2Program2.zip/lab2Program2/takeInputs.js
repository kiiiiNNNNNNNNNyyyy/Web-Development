'use strict'

const prompt = require("prompt");
const metrics =  require("./textMetrics");

var promise = new Promise(function(fulfill, reject){
	let UserString;
	console.log("\nEither Enter the String or Press Enter to use the Default String \n");
	console.log("\nDefault String : Hello, my friends!. This is a great day to say hello.\n");
	prompt.get(['yourText'], function (err, result) {
		console.log("Your Text : \n\n" + result.yourText);
		let userInput = result.yourText;
		if(userInput.localeCompare("") == 0){
			console.log("Showing Metrics for the default string : ");
			UserString = "Hello, my friends!. This is a great day to say hello.";
		}
		else{
			UserString = userInput;
			console.log("Showing metrics for you custom string : ");
		}

		fulfill(UserString);

	});
});	

promise.then(function(string){
	let test = metrics.createMetrics(string);
	test.then((input)=>{
		return;
	}).catch((error)=> {
		console.log(error);
	});
}).catch(function(err){
	
});

promise.then(function(){
	// unnecessay log to distingish between programs
	console.log("Metrics Created");
}).catch(function(err){
	console.log(err);
});
