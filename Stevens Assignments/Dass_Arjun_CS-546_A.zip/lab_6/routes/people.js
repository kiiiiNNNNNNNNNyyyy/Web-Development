'use strict'
const express = require('express');
const router = express.Router();
const data = require("../data");
const peopleData = data.people;
const eventsData = data.events;

// Single Person Page
router.get("/:id", (req, res) => {
    // Find a person by the provided id, 
    // then display their information
    // As well as listing all events that they will be attending
    // Each of these events need to link to the event page, and show the event name
    // If a person is not found, display the 404 error page
    peopleData.getPerson(req.params.id).then((person)=> {
        console.log(person);
        res.render("misc/people", {person: person});
        /*let personName =  person.name; 
        let personId = person.id; 
       /* var data ={};
        data.personName = personName;
        data.personId = personId;
        var transfer = data;*/
        
        /*eventsData.getEventsForAttendee(personId).then((allData)=>{
            console.log(allData);
            var data = {};
            data.personName = personName;
            data.personId = personId;
            data.eventsName = allData.title;
            data.eventsDesc = allData.desc;
            res.render("misc/peple", {peple:data});
        }); */
    });
});

// People Index Page
router.get("/", (req, res) => {	
    peopleData.getAllPeople().then((people)=>{
    	res.render("misc/people", {people: people});
    });
});

module.exports = router;