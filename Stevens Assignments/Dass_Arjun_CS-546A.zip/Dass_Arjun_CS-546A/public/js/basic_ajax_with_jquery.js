(function ($) {
    // Let's start writing AJAX calls!
    var test = [];

    var form = $('#form'),
    formTitle = $('#title'),
    formDueDate = $('#dueDate'),
    formSummary = $('#summary'),
    formBody = $('#body');

    form.submit(function(event){
    	event.preventDefault();

    	var title = formTitle.val();
    	var dueDate = formDueDate.val();
    	var summary = formSummary.val();
    	var body = formBody.val();
    	var newContent2 = $('#new-content2')

    	var newTest = {
    		title: title,
    		dueDate: dueDate,
    		summary: summary,
    		body: body
    	}

    	test.push(newTest);
    	localStorage.setItem('test', JSON.stringify(test));
    	var LocalStoredData = JSON.parse(localStorage.getItem('test'));
    	console.log(LocalStoredData);

    	if(title && dueDate && summary && body){
    		var formData = ({
    			method: "POST",
    			url: "api/new",
    			data: JSON.stringify({	
    				dueDate: dueDate,
    				title: title,
    				summary: summary,
    				body: body
    			}),
    			contentType : "application/json"
    		});

    		$.ajax(formData).then(function(response){
    			newContent2.html(response.title);
    		});
    	}
    });

    console.log(localStorage);
    var storedArray = localStorage.getItem("test");
    var y = JSON.parse(storedArray);
    //console.log(y);
    //console.log(typeof(storedArray));
    //console.log(y);

    for(var i=0; i<y.length;i++){
    	curr_item = y[i];
    	curr_title = curr_item.title;
    	curr_dueDate = curr_item.dueDate;
    	curr_summary = curr_item.summary;
    	curr_body = curr_item.body;

    	var showTitle = curr_title;
    	var showDueDate=  curr_dueDate;
    	var showSummary = curr_summary;
    	var showBody = curr_body;

    	$('#showTitle').html(showTitle);
    	$('#showDueDate').html(showDueDate);
    	$('#showSummary').html(showSummary);
    	$('#showBody').html(showBody);

    	document.write("<div class='container'><div class='col-md-3'>" + showTitle + "</div>");
    	document.write("<div class='col-md-3'>" + showDueDate + "</div>")
    	document.write("<div class='col-md-3'>" + showSummary + "</div>")
    	document.write("<div class='col-md-3'>" + showBody + "</div></div>")
    }

    var myNewTaskForm = $("#new-item-form"),
    newNameInput = $("#new-task-name"),
    newDecriptionArea = $("#new-task-description");

    myNewTaskForm.submit(function (event) {
    	event.preventDefault();

    	var newName = newNameInput.val();
    	var newDescription = newDecriptionArea.val();
    	var newContent = $("#new-content");

    	if (newName && newDescription) {
    		var requestConfig = {
    			method: "POST",
    			url: "/api/todo",
    			contentType: 'application/json',
    			data: JSON.stringify({
    				name: newName,
    				description: newDescription,
    				testField: 12,
    				testBool: true
    			})
    		};

    		$.ajax(requestConfig).then(function (responseMessage) {
    			newContent.html(responseMessage.message);
                //                alert("Data Saved: " + msg);
            });
    	}
    });
})(window.jQuery);