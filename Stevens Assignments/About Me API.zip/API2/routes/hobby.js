'use strict'
const express = require('express');
const router = express.Router();
const data = require("../data");
const hobbyData = data.hobby;
const hobbyDescriptionData = data.hobbyDescription;

router.get("/:id", (req, res) => {
    hobbyDescriptionData.getHobbyDescripionByName(req.params.id).then((hobbyDescription) => {
        res.json(hobbyDescription);
    }, (error) => {
        // Not found!
        res.sendStatus(404);
    });
});

router.get("/", (req, res) => {
    hobbyData.getAllHobby().then((hobbyList) => {
        res.json(hobbyList);
    }, () => {
        // Something went wrong with the server!
        res.sendStatus(500);
    });
});

router.post("/", (req, res) => {
    // Not implemented
    res.sendStatus(501);
});

module.exports = router;