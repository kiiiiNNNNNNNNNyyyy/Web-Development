'use strict'

const fileModule = require('./module.js');
const prompt = require('prompt');

console.log("Start of the Code");
let readTextFile = fileModule.getFileAsString("TextDocument.txt");

readTextFile.then((textData) => {
	return console.log("Reached");
}).catch((error) => {
	console.log("Something Went Wrong");
	console.log(error);
});

/******************** Program 2 *******************************/

let readJSON = fileModule.getFileAsJSON("Data.json");

readJSON.then((jsonData) => {
	return;
}).catch((error) => {
	console.log("Something Went Wrong");
	console.log(error);
});

/************************* Program 3*****************************/

prompt.start();
let promise = new Promise(function(fulfill, reject){
	prompt.get(['yourText'], function (err, result) {
    console.log("Your Text : \n\n" + result.yourText + "\n\n has been wrtiten to the file yourText.txt");
    let userInput = result.yourText;
    fulfill(userInput);
  });
});

promise.then(function(input){
	let writeStringToFile = fileModule.saveStringToFile("yourText.txt",input);

	writeStringToFile.then((input)=>{
		return;
	}).catch((error)=> {
		console.log(error);
	});
}).catch(function(err){
	console.log(err);
});

promise.then(function(){
	// unnecessay log to distingish between programs
	console.log("\n ***********************************PROGRAM 4  ***********************")
	console.log("\n\n Your JSON data from Data.json file has been written to yourJsonText.txt \n");
}).catch(function(err){
	console.log(err);
});

/***************************** Program 4 *****************************/

let writeJSONToText = fileModule.saveJSONToFile("Data.json");

writeJSONToText.then((jsonData2) => {
	return;
}).catch((error) => {
	console.log("Something went wrong");
	console.log(error);
});