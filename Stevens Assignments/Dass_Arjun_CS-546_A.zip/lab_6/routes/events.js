'use strict'
const express = require('express');
const router = express.Router();
const data = require("../data");
const eventsData = data.events;
const locationData = data.locations;


// Event Index Page
router.get("/", (req, res) => {

    eventsData.getAllEvents().then((events) => {
         res.render("misc/events", { events: events});
    }).catch((err => {
        console.log(err);
    }));
});

// Single Event Page
router.get("/:id", (req, res) => {

    eventsData.getEvent(req.params.id).then((event)=>{
        let eventId = event.id;
        let eventTime = event.startTime;
        let eventDesc = event.description;
        let locationId  = event.location;
        let attendees = event.attendees;
        locationData.getLocation(locationId).then((allData)=>{
            console.log(allData);

            var data = {};
            data.eventId = eventId;
            data.eventTime =  eventTime;
            data.eventDesc = eventDesc;
            data.attendees = attendees;
            data.locationId = allData.id;
            data.locationName = allData.name;
            var transfer = data;
            console.log(transfer);
            res.render("misc/events", {event: transfer}); 
        });
    });
    // Find a event by the provided id, 
    // then display its information
    // As well as listing the names of all the attendees that will be at this event 
    // Each of these attendee names will need to link to their person page
    // You will also list the location of the event, said location's name, and a link to the location page

    // If a event is not found, display the 404 error page
}   );



module.exports = router;