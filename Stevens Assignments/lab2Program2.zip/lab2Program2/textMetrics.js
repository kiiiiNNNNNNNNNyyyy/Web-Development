'use strict'

let modules = exports = module.exports;


modules.createMetrics = (strings) => {

	let newWord = [];
	let sentences = [];

	let newWordCount = 0;
	let totalLetter = 0;
	let totalWord = 0;
	let UniqueWord = 1;
	let longWord = 0;
	let numberOfSentences = 0;
	let averageWordLength  = 0;
	let TimeComplexity = 0;

	let string = strings.toLowerCase();
	//counting total letters
	totalLetter =  string.replace(/[^A-Z]/gi, "").length;
	console.log("total letters : " + totalLetter +",");
	
	//counting total words
	var wordsArray = string.split(/[(.)(,)(!)( )]/gi);
	for(let i=0;i<wordsArray.length;i++){
		if(wordsArray[i] === ""){
			totalWord = totalWord;
		}
		else{
			totalWord++;
		}
	}
	console.log("total words : " + totalWord + ",");

	//counting number of sentences
	var sentencesArray = string.split(".");
	for(let j=0;j<sentencesArray.length;j++){
			numberOfSentences++;
		}
		numberOfSentences--;

	//Occurrences and Unique words
	let wordsObject = {};
	for(let i=0;i<wordsArray.length;i++){
		let currentNameOccurances = 0;
		let currentName = wordsArray[i];
		for(let j=0;j<wordsArray.length;j++){
			if(wordsArray[i].localeCompare(wordsArray[j]) === 0){
				currentNameOccurances++;					
			}
			wordsObject[currentName] = currentNameOccurances;
		}
	}

	//Unique Word
	let uniqueWordsArray = [];
	for(let key in wordsObject){
		if(wordsObject.hasOwnProperty(key)){
			if(wordsObject[key] === 1){
				UniqueWord++;
				uniqueWordsArray.push(key);
			}
		}
	}
	console.log("Unique words : "+UniqueWord);

	//long words
	for(let i=0; i<wordsArray.length;i++){
		if(wordsArray[i].length>6){
			longWord++;
		}
	}
	console.log("Long Words : "+longWord);

	//averageWordLength
	averageWordLength = (totalLetter/totalWord).toFixed(2);
	console.log("Average Word Length : " + averageWordLength);

	//TimeComplexity

	TimeComplexity = (totalWord/numberOfSentences + (longWord * 100)/totalWord).toFixed(2);
	console.log("Time Complexity is : " + TimeComplexity); 
	if(numberOfSentences == 0){
		console.log("Time Complexity is Infinity because number of sentences is  0");
	}

	//Print Number of Sentences
	console.log("Number of Sentences : " + numberOfSentences);

	//words
	console.log(wordsObject);

}
