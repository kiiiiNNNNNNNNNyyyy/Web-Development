'use strict'
const express = require('express');
const router = express.Router();
const data = require("../data");
const classesData = data.classes;
const classesDescriptionData = data.classesDescription;

router.get("/details", (req, res) => {
    let coded = req.query.code;
    classesDescriptionData.getClassesDescripionByName(coded).then((classes) => {
        res.json(classes);
    }, (error) => {
        // Not found!
        res.sendStatus(404);
    });
});

router.get("/", (req, res) => {
    classesData.getAllClasses().then((ClassesList) => {
        res.json(ClassesList);
    }, () => {
        // Something went wrong with the server!
        res.sendStatus(500);
    });
});

router.post("/", (req, res) => {
    // Not implemented
    res.sendStatus(501);
});

module.exports = router;