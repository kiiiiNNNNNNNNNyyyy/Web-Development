'use strict'
const mongoCollections = require("../config/mongoCollections");
const hobbyDescription = mongoCollections.hobbyDescription;
const hobbies = require('./hobby');
const uuid = require('node-uuid');

let exportedMethods = {
    getHobbyDescripionByName(hobbyName){
        return hobbyDescription().then((hobbyDescriptionCollection) => {
            return hobbyDescriptionCollection.findOne({hobbyName:hobbyName}).then((hobby) => {
                if(!hobby){
                    throw "Hobby Not Found";
                }
                return hobby;
            });
        });
    },

    getHobbyDescripionById(id){
        return hobbyDescription().then((hobbyDescriptionCollection) => {
            return hobbyDescriptionCollection.findOne({_id:id}).then((hobby) => {
                if(!hobby){
                    throw "Hobby Not Found";
                }
                return hobby;
            });
        });
    },

    getAllHobiesDescription(){
        return hobbyDescription().then((hobbyDescriptionCollection) => {
            return hobbyDescriptionCollection.find({}).toArray();
        });
    },

    addHobbyDescription(hobbyName, body){
        return hobbyDescription().then((hobbyDescriptionCollection) => {
                    let newHobbyDescription = {
                    hobbyName: hobbyName,
                    body: body,
                    _id:uuid.v4()
                };

                return hobbyDescriptionCollection.insertOne(newHobbyDescription).then((newHobbyDescriptionInserted) => {
                    return newHobbyDescriptionInserted.insertedId;
                }).then((newId) => {
                    return this.getHobbyDescripionById(newId);
                });
            });
        }
}

module.exports =  exportedMethods;