'use strict'
const fs = require("fs");
const readMultipleFiles = require('read-multiple-files');
let modules = exports = module.exports;

modules.writeFile = (fileName,callback) => {

	return new Promise((fulfill, reject) => {
		if(!fileName) throw "No File name has been provided";

		readMultipleFiles(['chapter1.txt', 'chapter2.txt', 'chapter3.txt'], 'utf8', (err, contents) => {
			if (err) {
				throw err;
			}
  			 
  			try{
  				let data = contents.toString();
  				console.log(data);
  			}catch(err){
  				reject(err);
  			}
		});
	});
}

