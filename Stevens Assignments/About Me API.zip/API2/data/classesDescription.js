'use strict'
const mongoCollections = require("../config/mongoCollections");
const classesDescription = mongoCollections.classesDescription;
const classes = require('./classes');
const uuid = require('node-uuid');

let exportedMethods = {
    getClassesDescripionByName(classesName){
        return classesDescription().then((classesDescriptionCollection) => {
            return classesDescriptionCollection.findOne({classesName:classesName}).then((classes) => {
                if(!classes){
                    throw "classes Not Found";
                }
                return classes;
            });
        });
    },

    getClassesDescripionById(id){
        return classesDescription().then((classesDescriptionCollection) => {
            return classesDescriptionCollection.findOne({_id:id}).then((classes) => {
                if(!classes){
                    throw "classes Not Found";
                }
                return classes;
            });
        });
    },

    addClassesDescription(classesName, professor, body){
        return classesDescription().then((classesDescriptionCollection) => {
            let newClassesDescription = {
                classesName: classesName,
                professor: professor,
                body: body,
                _id:uuid.v4()
            };

            return classesDescriptionCollection.insertOne(newClassesDescription).then((newClassesDescriptionInserted) => {
                return newClassesDescriptionInserted.insertedId;
            }).then((newId) => {
                return this.getClassesDescripionById(newId);
            });
        });     
    }
}

module.exports =  exportedMethods;