'use strict'
const express = require('express');
const router = express.Router();
const data = require("../data");
const classesDescriptionData = data.classesDescription;

router.get("/:id", (req, res) => {
    classesDescriptionData.getclassesDescripionById(req.params.id).then((classesDescription) => {
        res.json(classesDescription);
    }, (error) => {
        // Not found!
        res.sendStatus(404);
    });
});

router.post("/", (req, res) => {
    // Not implemented
    res.sendStatus(501);
});

module.exports = router;