// Remember, we're in a browser: prevent global variables from happening
// I am passing the jQuery variable into the IIFE so that
// I don't have to rely on global variable name changes in the future
(function ($, localStorage) {
    

    var localStorageTableBody = $("#localstorage-data tbody");
    var clearStorage = $("#clear-storage");
    var submitted = $("#submit");
    var body = $("#body");
    
    var myTimer, c;
    $(document).ready(function(){
        myTimer = setInterval(1500);

        submitted.click(function(){
            c = myTimer
        });
    });

    $("#change-hash").click(function() {
        alert("normally, clicking a hash does not trigger a reload; we are reloading to show the hash field update")

        window.setTimeout(function() {
            location.reload();
        }, 500);
    });

    var count = 0, normalcount = 0;
    var check = setInterval(function(){
        count++;
    }, 1500);
    var check2 = setInterval(function(){
        normalcount++;
    },1000);
    var x = 0;

    var keyNameInput = $("#localstorage-key");
    var keyValueInput = $("#localstorage-value");
    var kvpForm = $("#localstorage-form");
    var formAlert = $("#form-alert");

    submitted.click(function (){
        x++;
        
    })

    var url = window.location.href;
    var type = window.location.hash.substr(1);
    if(!type){
        hash = "No Hash";
    }else{
        hash = type;
    }

    function resetTable() {
        localStorageTableBody.empty();

        // We use the localStorage.key(number) property to get the key name at index number
        for (var i = 0; i < localStorage.length; i++) {
            var currentKey = localStorage.key(i);
            var curentValue = localStorage[currentKey];
            var currentUrl = url; 
            var currentHash = hash;
            var currentCount = count;

            var asJSON = JSON.parse(curentValue);
            var typeAfterParsing = typeof asJSON;

            var newHtmlString = "<tr><td>" + i + "</td><td>" + curentValue + "</td><td>" + x + "</td><td>" + currentCount + "</td><td>" + normalcount + "</td>  <td>" + url +"</td><td>" + currentHash + "</td></tr>"
            localStorageTableBody.append(newHtmlString);
        }
    }   


    clearStorage.click(function () {
        localStorage.clear();
        resetTable();
    });

    kvpForm.submit(function (event) {
        event.preventDefault();

        // reset the form
        formAlert.addClass('hidden');
        formAlert.text('');

        var keyStr = x;
        var valStr = keyValueInput.val();
        var locStr = url;

        if (!keyStr) {
            formAlert.text('You must provide a key name');
            formAlert.removeClass('hidden');
            return;
        }

        if (!keyValueInput) {
            formAlert.text('You must provide a key name');
            formAlert.removeClass('hidden');
            return;
        }

        // check if it's in the format of an object
        var jsonString = valStr;

        try {
            // this will throw when given a non JSON string
            JSON.parse(valStr);

            // if this succeeded, the user passed us something we could parse, and we don't have to encode it further
        } catch (e) {
            // this did not succeed, which means that the user passed us some sort of string
            jsonString = JSON.stringify(valStr);
        }

        localStorage[keyStr] = jsonString;

        keyNameInput.val('');
        keyValueInput.val('');


        resetTable();
    });

    // Now we setup our table
    resetTable();
})(jQuery, window.localStorage);
// jQuery is exported as $ and jQuery
// the location API is accessed via the window.location variable
