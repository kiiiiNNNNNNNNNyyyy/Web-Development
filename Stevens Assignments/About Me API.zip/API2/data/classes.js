'use strict'
const mongoCollections = require("../config/mongoCollections");
const classes = mongoCollections.classes;
const classesDescription = mongoCollections.classesDescription;
const uuid = require('node-uuid');

let exportedMethods = {
    getAllClasses() {
        return classes().then((classesCollection) => {
            return classesCollection.find({}).toArray();
        });
    },
    // This is a fun new syntax that was brought forth in ES6, where we can define
    // methods on an object with this shorthand!
    getClassesByName(classesName) {
        return classes().then((classesCollection) => {
            return classesCollection.findOne({classesName: classesName}).then((classes) => {
                if (!classes) throw "classes not found";
                return classes;
            });
        });
    },

    getClassesById(id){
        return classes().then((classesCollection) => {
            return classesCollection.findOne({_id: id}).then((classes) => {
                if (!classes) throw "class not found";
                return classes;
            });
        });
    },

    addClasses(classesName) {
        return classes().then((classesCollection) => {
            let newClasses = {
                classesName: classesName,
                _id: uuid.v4()
            };

            return classesCollection.insertOne(newClasses).then((newInsertedClasses) => {
                return newInsertedClasses.insertedId;
            }).then((newId) => {
                return this.getClassesById(newId);
            });
        });
    }
}

module.exports = exportedMethods;