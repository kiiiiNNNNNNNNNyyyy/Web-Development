const text = require("./text");

module.exports = {
    text: text
};