'use strict'
const dbConnection = require("../config/mongoConnection");
const data = require("../data/");
const education = data.education;
const hobby = data.hobby;
const hobbyDescription = data.hobbyDescription;
const classes= data.classes;
const classesDescription = data.classesDescription;

dbConnection().then(db => {
    return db.dropDatabase().then(() => {
        return dbConnection;
    }).catch(err => {
    	console.log(err);
    }).then(() => {
    	return education.addEducation("Modern Era Convent", "SRM University");
    }).then(() => {
        return education.addHighSchool("Modern Era Convent");
    }).then(() => {
        return education.addUnderGrad("SRM University", "B.Tech");
    }).then(() => {
        return hobby.addHobby("Dancing");
    }).then((dancing)=>{
        return hobbyDescription.addHobbyDescription("Dancing", "I like to Dance. I have been dancing for 5 years. I am also a member of FootStomppers society of Stevens"); 
    }).then(() => {
        return hobby.addHobby("Gyming");
    }).then((gyming) => {
        return hobbyDescription.addHobbyDescription("Gyming", "I like to Gym. I have been Gyming for 3 years. I go to the gym everyday in stevens.");
    }).then(() => {
        return hobby.addHobby("Counter-Strike");
    }).then((cs)=>{
        return hobbyDescription.addHobbyDescription("Counter-Strike", "I like playig Counter-Strike. I have played counter strike for 5k hours. My rank is SMFC"); 
    }).then(() => {
    	return classes.addClasses("CS-546");
    }).then((class1) => {
    	return classesDescription.addClassesDescription("CS-546", "Phil Barresi","The name of this course is Web Programming. In this Course we will learn about developing web application using the MEAN stack");
    }).then(() => {
    	return classes.addClasses("CS-590");
    }).then((class2) => {
    	return classesDescription.addClassesDescription("CS-590", "David Preffer","The name of this course is Algorithm and in this course we will be focussing onvarious algorithms and  data structures.");
    }).then(() => {
    	return classes.addClasses("CS-561");
    }).then((class3) => {
    	return classesDescription.addClassesDescription("CS-561", "Kim Samuel", "The name of this course is DBMS and in this course we will learning about Database schema and and relation algebr, along with SQL.");
    }).then(() => {
    	return classes.addClasses("CS-545");
    }).then((class4) => {
    	return classesDescription.addClassesDescription("CS-545", "Gregg Vessondar","The name of this course is Human  Computer Interaction. In this course we will learn how to build a better and more interactive user interface.");
    }).then(() => {
    	return classes.addClasses("CS-600");
    }).then((class5) => {
    	return classesDescription.addClassesDescription("CS-600", "K. Duggan","The name of this course is Advance Algorithma and in this course we will learn about more coplex algorithms and their complexities.");
    }).then(() => {
        return classes.addClasses("CS-585");
    }).then((class6) => {
        return classesDescription.addClassesDescription("CS-585", "John Doe", "The name of this course is Introduction to Game Development and I'll be taking this course in next semester");
    }).catch(err => {
    	console.log(err);
    }).then(() => {
        console.log("Done seeding database");
        db.close();
    });
}, (error) => {
    console.error(error);
});
