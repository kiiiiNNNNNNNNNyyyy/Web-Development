'use strict'
const educationData = require("./education");
const hobbyData = require("./hobby");
const classesData = require("./classes");
const hobbyDescriptionData = require("./hobbyDescription");
const classesDescriptionData = require("./classesDescription");

module.exports = {
    education: educationData,
    hobby: hobbyData,
    hobbyDescription: hobbyDescriptionData,
    classes: classesData,	
    classesDescription: classesDescriptionData
};