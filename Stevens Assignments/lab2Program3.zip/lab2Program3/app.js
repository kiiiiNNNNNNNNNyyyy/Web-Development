'use strict'

const print = require('./modules.js');

let printData = print.writeFile("Hello.txt");

printData.then((data) => {
	return;
}).catch((err) => {
	console.log("Something Went Wrong");
	console.log(err);
})
